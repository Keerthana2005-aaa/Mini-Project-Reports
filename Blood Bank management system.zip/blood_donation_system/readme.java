Blood Bank Management System

## Class Overview

- **bloodbank.core.BloodBank**: Manages donors, requests, and donations.
- **bloodbank.core.BloodDonor**: Represents a blood donor.
- **bloodbank.requests.BloodRequest**: Represents a blood request.
- **bloodbank.requests.BloodDonation**: Represents a blood donation.
- **bloodbank.ui.BloodBankUI**: Main user interface (console or Swing).

## Database Setup (MySQL)

1. **Install MySQL** and create a database named `blood_bank`.
2. **Create the required tables** using the sample SQL below.
3. **Update the database credentials** in your Java code if needed.

## Sample SQL Schema

```sql
CREATE DATABASE IF NOT EXISTS blood_bank;
USE blood_bank;

CREATE TABLE IF NOT EXISTS Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(50) NOT NULL,
    role ENUM('Admin', 'Hospital', 'Donor', 'Recipient') NOT NULL
);

CREATE TABLE IF NOT EXISTS BloodStock (
    blood_group VARCHAR(5) PRIMARY KEY,
    units INT DEFAULT 0
);

INSERT INTO BloodStock (blood_group, units) VALUES
('A+', 10), ('A-', 10), ('B+', 10), ('B-', 10),
('AB+', 10), ('AB-', 10), ('O+', 10), ('O-', 10)
ON DUPLICATE KEY UPDATE units=units;

CREATE TABLE IF NOT EXISTS Transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    transaction_type VARCHAR(20),
    blood_group VARCHAR(5),
    units INT,
    description VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

CREATE TABLE IF NOT EXISTS Camps (
    camp_id INT AUTO_INCREMENT PRIMARY KEY,
    hospital_user_id INT,
    location VARCHAR(100),
    camp_date DATE,
    capacity INT,
    FOREIGN KEY (hospital_user_id) REFERENCES Users(user_id)
);
```

## How to Run in java

1. **Compile all Java files** (from the project root):

    ```sh
    javac -cp ".;C:\Users\2023k\Desktop\BankDatabase\mysql-connector-j-9.2.0.jar" bloodbank/core/*.java bloodbank/requests/*.java bloodbank/ui/*.java
    ```

2. **Run the main UI class**:

    ```sh
    java -cp ".;C:\Users\2023k\Desktop\BankDatabase\mysql-connector-j-9.2.0.jar" bloodbank.ui.BloodBankUI
    ```

    - On Linux/Mac, replace `;` with `:` in the classpath.

3. **Ensure MySQL is running** and the database is set up.

## Usage

- **Admin**: Can view and update blood stocks, view all transactions.
- **Hospital**: Can request blood, conduct camps, view requests.
- **Donor**: Can check eligibility, donate blood, get donation certificate.
- **Recipient**: Can request blood.

Follow the on-screen menu or GUI prompts to interact with the system.

## Notes

- Update the MySQL username and password in `BloodBankUI.getConnection()` as per your setup.
- The MySQL connector JAR (`mysql-connector-j-9.2.0.jar`) must be present and referenced in your classpath.
- All data is stored in the MySQL database.
- For any issues, check your database connection and table setup.

-Contributions
-If you want to contribute to this project:
1.	Fork the repository.
2.	Create a branch for your feature or fix.
3.	Commit your changes and push them to your forked repository.
4.	Create a pull request with a detailed description of your changes.
-License
-This project is licensed under the MIT License.

## Author

- [Keerthana.H]
