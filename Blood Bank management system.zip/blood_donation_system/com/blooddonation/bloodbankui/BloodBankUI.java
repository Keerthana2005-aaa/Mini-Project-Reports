package com.blooddonation.bloodbankui;

import javax.swing.*; // ✅ For GUI components
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.blooddonation.accountmanagement.TransactionManager;
import com.blooddonation.accountmanagement.AccountManager; // ✅ For AccountManager
import com.blooddonation.bloodmanagement.BloodInventory;
import com.blooddonation.bloodmanagement.DashboardFactory;

public class BloodBankUI {
    private JFrame frame;
    private JPanel mainPanel;
    public static AccountManager accountManager;
    public static BloodInventory bloodInventory;
    public static TransactionManager transactionManager;
    private DashboardFactory dashboardFactory;

    public BloodBankUI() {
        frame = new JFrame("Blood Bank Management System");
        frame.setSize(1000, 1000);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        if (accountManager == null) accountManager = new AccountManager();
        if (bloodInventory == null) bloodInventory = new BloodInventory();
        if (transactionManager == null) transactionManager = new TransactionManager();

        dashboardFactory = new DashboardFactory(bloodInventory, transactionManager, this);

        showStartScreen();
        frame.setVisible(true);
    }

    public void showStartScreen() {
        // method implementation as before
    }

    public void showRegisterScreen() {
        // method implementation as before
    }

    public void showLoginScreen() {
        // method implementation as before
    }

    private void showDashboard(String role, String username) {
        // method implementation as before
    }

    public JPanel createStartScreen() {
        showStartScreen();
        return mainPanel;
    }

    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/blood_bank";
        String user = "root";
        String password = "Keerthana@09022005"; // Update with your MySQL password
        return DriverManager.getConnection(url, user, password);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BloodBankUI::new);
    }
}

