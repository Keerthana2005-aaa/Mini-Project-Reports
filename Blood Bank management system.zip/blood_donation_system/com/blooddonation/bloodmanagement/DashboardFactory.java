package com.blooddonation.bloodmanagement;

import javax.swing.*; // ✅ For JPanel, JFrame
import java.awt.event.ActionListener; // ✅ For ActionListener
import java.sql.SQLException; // ✅ For SQLException

import com.blooddonation.accountmanagement.TransactionManager;
import com.blooddonation.bloodbankui.BloodBankUI;

public class DashboardFactory {
    private BloodInventory bloodInventory;
    private TransactionManager transactionManager;
    private BloodBankUI bloodBankUI;

    public DashboardFactory(BloodInventory bloodInventory, TransactionManager transactionManager, BloodBankUI bloodBankUI) {
        this.bloodInventory = bloodInventory;
        this.transactionManager = transactionManager;
        this.bloodBankUI = bloodBankUI;
    }

    public JPanel createDashboard(String role, String username, JFrame frame) {
        // method implementation as before
        return new JPanel(); // temporary dummy return so it compiles
    }

    public JButton addButton(JPanel panel, String label, ActionListener listener) {
        JButton button = new JButton(label);
        panel.add(button);
        button.addActionListener(listener);
        return button;
    }

    private void checkEligibility(String username, JFrame frame) throws SQLException {
        // method implementation as before
    }
}
