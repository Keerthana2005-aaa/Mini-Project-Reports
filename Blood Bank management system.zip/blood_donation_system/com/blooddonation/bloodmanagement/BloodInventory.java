

package com.blooddonation.bloodmanagement;

import javax.swing.*;
import java.sql.SQLException;

import com.blooddonation.accountmanagement.TransactionManager;


public class BloodInventory {
    public void viewBloodStocks(JFrame frame) throws SQLException {
        // logic to view blood stocks
    }

    public void updateBloodStock(JFrame frame) throws SQLException {
        // logic to update blood stocks
    }

    public void requestBlood(String bloodGroup, TransactionManager transactionManager, String username, String role, JFrame frame) throws SQLException {
        // logic to request blood
    }

    public boolean isValidBloodGroup(String group) {
        // logic to validate blood group
        return true;
    }

    public void donateBlood(String group, TransactionManager transactionManager, String name, String username, JFrame frame) throws SQLException {
        // logic to donate blood
    }
}
