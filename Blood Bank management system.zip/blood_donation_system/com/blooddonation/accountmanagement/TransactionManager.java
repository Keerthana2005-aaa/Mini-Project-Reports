package com.blooddonation.accountmanagement;

import javax.swing.JFrame; // ✅ For JFrame
import java.sql.SQLException; // ✅ For SQLException


public class TransactionManager {
    public void conductCamp(JFrame frame, String username) throws SQLException {
        // logic to conduct camp
    }

    public void viewTransactions(JFrame frame) throws SQLException {
        // logic to view transactions
    }
}
