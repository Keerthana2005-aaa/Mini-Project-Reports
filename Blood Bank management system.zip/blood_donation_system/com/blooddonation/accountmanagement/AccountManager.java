
package com.blooddonation.accountmanagement;

import java.sql.*;
import com.blooddonation.bloodbankui.BloodBankUI;


public class AccountManager {
    public void registerUser(String role, String username, String password) throws SQLException {
        try (Connection connection = BloodBankUI.getConnection()) {
            String sql = "INSERT INTO users (role, username, password) VALUES (?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, role);
                statement.setString(2, username);
                statement.setString(3, password);
                statement.executeUpdate();
            }
        }
    }

    public boolean validateLogin(String role, String username, String password) throws SQLException {
        try (Connection connection = BloodBankUI.getConnection()) {
            String sql = "SELECT * FROM users WHERE role = ? AND username = ? AND password = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, role);
                statement.setString(2, username);
                statement.setString(3, password);
                ResultSet rs = statement.executeQuery();
                return rs.next();
            }
        }
    }
}
